package PageBean;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferencePageBean {
	WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pffname;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	WebElement pfbutton;
	
	@FindBy(how=How.ID , using="txtLastName")
	@CacheLookup
	WebElement pflname;
	
	@FindBy(how=How.NAME, using="Email")
	@CacheLookup
	WebElement pfemail;
	
	@FindBy(css="input[pattern='[789][0-9]{9}']")
	@CacheLookup
	WebElement pfmobile;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[5]/td[1]")
	@CacheLookup
	int pfpersons;

	@FindBy(how=How.NAME, using="Address")
	@CacheLookup
	WebElement pfbuild;
	
	@FindBy(how=How.NAME, using="Address2")
	@CacheLookup
	WebElement pfarea;
	

	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement pfcity;
	
	@FindBy(how=How.NAME, using="state")
	@CacheLookup
	WebElement pfstate;
	
	@FindBy(how=How.NAME , name="memberStatus")
	@CacheLookup
	private List<WebElement> memberStatus;
	

	public List<WebElement> getMemberStatus() {
		return memberStatus;
	}

	

	public ConferencePageBean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getPffname() {
		return pffname;
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	public WebElement getPflname() {
		return pflname;
	}

	public WebElement getPfemail() {
		return pfemail;
	}

	public WebElement getPfmobile() {
		return pfmobile;
	}

	public int getPfpersons() {
		return pfpersons;
	}

	public WebElement getPfbuild() {
		return pfbuild;
	}

	public WebElement getPfarea() {
		return pfarea;
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public WebElement getPfstate() {
		return pfstate;
	}

	

	public void setPffname(String sfname) {
		pffname.sendKeys(sfname);
	}

	public void setPfbutton() {
		pfbutton.click();
	}

	public void setPflname(String slname) {
		pflname.sendKeys(slname);
	}

	public void setPfemail(String semail) {
		pfemail.sendKeys(semail);
	}

	public void setPfmobile(String smobile) {
		pfmobile.sendKeys(smobile);
	}
	
	public void setMemberStatus(String memberStatus) {
		if(memberStatus.equals("member"))
			this.memberStatus.get(0).click();
		else if(memberStatus.equals("non-member"))
			this.memberStatus.get(1).click();
	}

	public void setPfpersons(int arg1) {
		pfpersons = arg1;
	}

	public void setPfbuild(String sfbuild) {
		pfbuild.sendKeys(sfbuild);
	}

	public void setPfarea(String sarea) {
		pfarea.sendKeys(sarea);
	}

	public void setPfcity(String scity) {
		Select drpCity = new Select(pfcity);
		drpCity.selectByVisibleText(scity);
	}

	public void setPfstate(String sstate) {
		Select drpState = new Select(pfstate);
		drpState.selectByVisibleText(sstate);
	}

	
	
	

	
	
	
}
