package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingPageFactory {
WebDriver driver;

	@FindBy(name="userName")
	@CacheLookup
	WebElement pfusname;
	
	@FindBy(xpath=".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
    @CacheLookup
    WebElement pfbutton;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pfuspassword;
	
	
	public void setPfusname(String susname) {
		pfusname.sendKeys(susname);
	}

	public void setPfuspassword(String suspassword) {
		pfuspassword.sendKeys(suspassword);
	} 
	public void setPfbutton() {
		pfbutton.click();
		}

	public WebElement getPfusname() {
		return pfusname;
	}
	

	public WebElement getPfbutton() {
		return pfbutton;
	}
	
	public WebElement getPfuspassword() {
		return pfuspassword;
	}

	public HotelBookingPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
}
