package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;

public interface IProductService {
	
	public Product getProductDetails(int productCode);

}
