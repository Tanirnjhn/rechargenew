package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		Scanner scanner=new Scanner(System.in);
		int Linetotal;                           //To calculate Line total
		
		System.out.println("ENTER 1 TO GENERATE BILL AND 2 TO EXIT");
		int choice=scanner.nextInt();
		
		switch(choice)
		{
		case 1: 
			IProductService iproductservice=new ProductService();
		    System.out.println("-----Enter product Code------");
		    int productCode=scanner.nextInt();
		    System.out.println(iproductservice.getProductDetails(productCode));
		    System.out.println("------Enter the quantity-----");
		    int quantity=scanner.nextInt();
		
		    System.out.println("Please confirm your price once again by entering the above price");
		    int price=scanner.nextInt();
		    Linetotal=price * quantity;	
		    System.out.println("Line Total is:" +Linetotal);
		    
		    
	  case 2: System.exit(0);
		        break;
		        
	  default: 
			    System.out.println("Wrong Choice");
		}
			

	}

} 