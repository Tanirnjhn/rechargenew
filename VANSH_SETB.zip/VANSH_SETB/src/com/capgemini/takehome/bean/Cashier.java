package com.capgemini.takehome.bean;

public class Cashier {
	
	private int quantity;
	private int linetotal;
	private String description;
	
	
	//-------------Superclass Constructor--------------//
	public Cashier() {
		super();
		// TODO Auto-generated constructor stub
	}


	//------------Parameterized Constructor-------------//
	public Cashier(int quantity, int linetotal, String description) {
		super();
		this.quantity = quantity;
		this.linetotal = linetotal;
		this.description = description;
	}


	
	//--------------Setter and Getter---------------//
	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public int getLinetotal() {
		return linetotal;
	}


	public void setLinetotal(int linetotal) {
		this.linetotal = linetotal;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}

	
	
	
	//-----------------toString Method-------------//
	@Override
	public String toString() {
		return "Cashier [quantity=" + quantity + ", linetotal=" + linetotal + ", description=" + description + "]";
	}
	

}
